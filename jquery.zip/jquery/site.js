$('#circle').click(function() {
  $('img').attr('src', 'panda.jpg');
});

$('.square').click(function() {
  $(this).css('width', '400px');
  });
